﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-LLKQ9MN;Database=FootballersExam;Integrated Security = true;TrustServerCertificate=True";
    }
}
