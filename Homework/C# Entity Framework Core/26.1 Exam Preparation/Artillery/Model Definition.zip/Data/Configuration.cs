﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-LLKQ9MN;Database=Artillery;Integrated Security = true;TrustServerCertificate=True";
    }
}
