﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Box
{
    public class Box<T>
    {
        public Box(T element)
        {
            Element = element;
        }
        public Box(List<T> elements)
        {
            Elements = elements;
        }
        public List<T> Elements
        {
            get;
        }
        public T Element
        {
            get;
        }
        public void Swap(List<T> elements, int firstIndex, int secondIndex)
        {
            T firstElement = elements[firstIndex];
            elements[firstIndex] = elements[secondIndex];
            elements[secondIndex] = firstElement;
        }
        public override string ToString()
        {
            var sb = new StringBuilder();
            foreach (var element in Elements)
            {
                sb.AppendLine($"{element.GetType()}: {element}");
            }
            //return $"{typeof(T)}: {Element}";
            return sb.ToString().Trim();
        }
    }
}
