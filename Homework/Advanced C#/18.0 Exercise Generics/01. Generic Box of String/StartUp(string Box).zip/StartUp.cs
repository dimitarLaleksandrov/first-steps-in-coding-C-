﻿using System;

namespace Box
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var lineNUms = int.Parse(Console.ReadLine());
            for (int i = 1; i <= lineNUms; i++)
            {
                var input = int.Parse(Console.ReadLine());
                var box = new Box<int>(input);
                Console.WriteLine(box);
            }
        }
    }
}
