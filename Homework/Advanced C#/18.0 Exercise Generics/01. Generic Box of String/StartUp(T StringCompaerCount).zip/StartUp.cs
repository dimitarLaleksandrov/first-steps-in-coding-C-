﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Box
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var lineNums = int.Parse(Console.ReadLine());
            //var list = new List<int>();
            //for (int i = 1; i <= lineNums; i++)
            //{
            //    var input = int.Parse(Console.ReadLine());
            //    list.Add(input);
            //}
            //var box = new Box<int>(list);
            //var indexses = Console.ReadLine().Split().Select(int.Parse).ToArray();
            //box.Swap(list, indexses[0], indexses[1]);
            //Console.WriteLine(box);
            var list = new List<string>();
            for (int i = 1; i <= lineNums; i++)
            {
                var input = Console.ReadLine();
                list.Add(input);
            }
            var box = new Box<string>(list);
            var compareElement = Console.ReadLine();
            var count = box.Count(list, compareElement);
            Console.WriteLine(count);
        }
    }
}
