﻿using System.Collections.Generic;

namespace FootballManager.ViewModels.Players
{
    public class AllPlayersViewModel
    {
        public IEnumerable<PralyersViewModel> Players { get; set; }
    }
}
