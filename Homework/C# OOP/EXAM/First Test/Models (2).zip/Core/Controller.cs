﻿using PlanetWars.Core.Contracts;
using PlanetWars.Models.Planets;
using PlanetWars.Repositories;
using System;
using System.Collections.Generic;
using System.Text;

namespace PlanetWars.Core
{
    public class Controller : IController
    {
        private readonly PlanetRepository planets;
        public Controller()
        {
            this.planets = new PlanetRepository();
        }
        public string AddUnit(string unitTypeName, string planetName)
        {
            throw new NotImplementedException();
        }

        public string AddWeapon(string planetName, string weaponTypeName, int destructionLevel)
        {
            throw new NotImplementedException();
        }

        public string CreatePlanet(string name, double budget)
        {
            var planet = planets.FindByName(name);
            if(planet != null)
            {
                return $"Planet {planet.Name} is already added!"; 
            }
            var planetToAdd = new Planet(name, budget);
            planets.AddItem(planetToAdd);
            return $"Successfully added Planet: {name}";
        }

        public string ForcesReport()
        {
            throw new NotImplementedException();
        }

        public string SpaceCombat(string planetOne, string planetTwo)
        {
            throw new NotImplementedException();
        }

        public string SpecializeForces(string planetName)
        {
            throw new NotImplementedException();
        }
    }
}
