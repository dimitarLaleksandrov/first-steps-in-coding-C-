﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04.WildFarm.Exeptions
{
    public static class ExceptionMeseges
    {
        public const string FoodNotPrefered = "{0} does not eat {1}!";
    }
}
