﻿namespace P04.WildFarm.Models.Animals.Mammals
{
    public interface ICat
    {
        string ProduceSounde();
    }
}