﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Core
{
    public interface IEngine
    {
        void Start();
    }
}
