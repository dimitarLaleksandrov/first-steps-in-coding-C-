﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony.Models.Interface
{
    public interface ICalable
    {
        string Call(string number);  
    }
}
