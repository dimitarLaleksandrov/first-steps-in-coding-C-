﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony.Models.Interface
{
    public interface IBrowseble
    {
        string BrowseURl(string url);
    }
}
