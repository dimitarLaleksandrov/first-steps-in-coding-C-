﻿namespace Library.Models.Books
{
    public class BookCategoryModel
    {
        public int Id { get; init; }

        public string Name { get; init; }
    }
}
