﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using static Contacts.Data.DataConstants.AppUser;

namespace Contacts.Data.Entities
{
    public class ApplicationUser : IdentityUser
    {
        [Required]
        [MaxLength(AppUserNameMaxLength)]
        public override string UserName
        {
            get => base.UserName;
            set => base.UserName = value;
        }

        [Required]
        [MaxLength(AppUserEmailMaxLength)]
        public override string Email
        {
            get => base.Email;
            set => base.Email = value;
        }

        public ICollection<ApplicationUserContact> ApplicationUsersContacts { get; set; }
    }
}
