﻿using System.ComponentModel.DataAnnotations;

using static Contacts.Data.DataConstants.Contact;
namespace Contacts.Data.Entities
{
    public class Contact
    {
        public int Id { get; set; }

        [Required]
        [StringLength(ContactFirstNameMaxLength)]
        public string FirstName { get; set; }

        [Required]
        [StringLength(ContactLastNameMaxLength)]
        public string LastName { get; set; }

        [Required]
        [EmailAddress]
        [StringLength(ContactEmailMaxLength)]
        public string Email { get; set; }

        [Required]
        [StringLength(ContactPhoneNumberMaxLength)]
        public string PhoneNumber { get; set; }
        public string? Address { get; set; }

        [Required]
        public string Website { get; set; }
        public ICollection<ApplicationUserContact> ApplicationUsersContacts { get; set; }

    }
}
